package com.calculator.stringcalculatorapp;

import java.util.ArrayList;
import java.util.List;

import com.calculator.stringcalculatorapp.exception.ParsingException;


public class StringCalculatorUtil {
	

	/**
	 *  Method to validate if the expression string contains alphabets instead of digits & to check if two delimiters - COMMA & NEWLINE , are present next to each other 
	 *  @param expression		User entered input in the form of a String
	 *  
	 *  **/

	public static void validateExpression(String expression) throws ParsingException {
		
		if(hasDelimitersNextToEachOther(expression, StringCalculatorConstants.COMMA_DELIM, StringCalculatorConstants.NEWLINE_DELIM)) {
			throw new ParsingException(StringCalculatorConstants.COMMA_NEWLINE_NEXT_TO_EACH_OTHER);
		}
		
		if( !expression.contains(StringCalculatorConstants.DOUBLE_BACKSLASH) && expression.matches(".*[a-zA-Z]+.*")) {
			throw new ParsingException(StringCalculatorConstants.CONTAINS_ALPHABETS);
		}
	}
	
	/**
	 *  Boolean method to check if the expression string contains the delimiter specified as arguments  
	 *  @param expression		User entered input in the form of a String
	 *  @param delimiter		Delimiter to be checked in the expression
	 *  
	 *  **/
	
	public static boolean containsDelimiter(String expression,String delimiter) {	
		if( expression.contains(delimiter) ) {
			return true;
		}else
			return false;
	}

	/**
	 *  Boolean method to check if the expression string contains both the delimiters specified as arguments  
	 *  @param expression		User entered input in the form of a String
	 *  @param delimiter1		First Delimiter to be checked
	 *  @param delimiter2		Second Delimiter to be checked
	 *  
	 *  **/
	
	public static  boolean containsBothDelimiters(String expression,String delimiter1,String delimiter2) {	
		if( expression.contains(delimiter1) && expression.contains(delimiter2) ) {
			return true;
		}else
			return false;
	}
	
	/**
	 *  Method to convert a list of strings to an array of strings  
	 *  @param arr		List of strings 
	 *   
	 * **/
	
	public static String[] getStringArray(List<String> arr) 
    {   
        String str[] = new String[arr.size()]; 
        for (int j = 0; j < arr.size(); j++) { 
            str[j] = arr.get(j); 
        } 
  
        return str; 
    } 
	
	/**
	 *  Boolean method to check if the two delimiters (COMMA & NWLINE) are present next to each other 
	 *  @param expression		User entered input in the form of a String
	 *  @param delimiter1		First Delimiter to be checked
	 *  @param delimiter2		Second Delimiter to be checked
	 *   
	 * **/
	
	public static boolean hasDelimitersNextToEachOther(String expression ,String delimiter1,String delimiter2) {
		boolean hasDelimiterNextToEachOther = false;
		if ( !StringCalculatorUtil.containsBothDelimiters(expression, delimiter1, delimiter2))
			return false;
						
		List<Integer> delimiter1List = getIndexes(expression, delimiter1);
		List<Integer> delimiter2List = getIndexes(expression, delimiter2);
			
		int size = delimiter1List.size();			
		for(int i=0;i<size;i++) {
			int indexVal = delimiter1List.get(i);
			int oneMinusIndex = indexVal-1;
			int onePlusIndex = indexVal+1;
			if( delimiter2List.contains(oneMinusIndex) || delimiter2List.contains(onePlusIndex) ) {
				hasDelimiterNextToEachOther = true;
				break;
			}
		}				
		return hasDelimiterNextToEachOther;		
	}

	
	/**
	 *  Method to return a list containing indices of a specific delimiter the input expression string
	 *  @param expression		User entered input in the form of a String
	 *  @param delimiter		Delimiter whose indices the method will return
	 *   
	 * **/
	public static List<Integer> getIndexes(String expression , String delimiter) {

		List<Integer> intList = new ArrayList<Integer>();

		int index = -1;
		if( expression.startsWith(StringCalculatorConstants.DOUBLE_BACKSLASH)) {
			index = expression.indexOf(delimiter,expression.indexOf(StringCalculatorConstants.NEWLINE_DELIM));
		}else {
			index = expression.indexOf(delimiter);
		}
		
		int delimiterLength = delimiter.length();
		while (index >= 0) { 
		    intList.add(index);
		    index = expression.indexOf(delimiter, index + delimiterLength);
		}
		return intList;
	}

}
