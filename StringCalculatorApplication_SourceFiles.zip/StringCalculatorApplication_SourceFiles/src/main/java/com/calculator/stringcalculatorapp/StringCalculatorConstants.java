package com.calculator.stringcalculatorapp;

public class StringCalculatorConstants {

	public static final String DOUBLE_BACKSLASH="//";
	public static final  String PIPE="|";
	public static final  String NEWLINE_DELIM="\n";
	public static final  String COMMA_DELIM=",";
	
	public static final String COMMA_NEWLINE_NEXT_TO_EACH_OTHER = "Comma & NewLine Delimiters are next to each other.Delimiters needs to have numbers in between."; 
	public static final String CONTAINS_ALPHABETS = "Input contains Alphabets .Input can only be numbers.";
	public static final String NOT_A_NUMBER = "Failed to process ";
	public static final String NEGATIVE_NUMBER_NOT_ALLOWED = "negatives not allowed";
	
}
