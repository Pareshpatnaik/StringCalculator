package com.calculator.stringcalculatorapp.tests;

import static com.calculator.stringcalculatorapp.StringCalculatorConstants.COMMA_DELIM;
import static com.calculator.stringcalculatorapp.StringCalculatorConstants.NEWLINE_DELIM;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.calculator.stringcalculatorapp.StringCalculatorUtil;
import com.calculator.stringcalculatorapp.exception.ParsingException;

public class StringCalculatorUtilTest {

	@Test(expected=ParsingException.class)
	public void testValidateExpression_CommaNewLine_NextToEachOther() throws ParsingException{
		String expression="1,\n";
		StringCalculatorUtil.validateExpression(expression);
	}

	@Test
	public void testValidateExpression() throws ParsingException{
		String expression="1\n2,3";
		StringCalculatorUtil.validateExpression(expression);
	}

	@Test(expected=ParsingException.class)
	public void testValidateExpression_Alphabets() throws ParsingException{
		String expression="1,\n,B,C";
		StringCalculatorUtil.validateExpression(expression);
	}
	
	@Test
	public void testContainsDelimiter_NewLine() {
		String expression="1\n2,3";
		boolean isDelimiterPresent = StringCalculatorUtil.containsDelimiter(expression, NEWLINE_DELIM);
		assertEquals(true, isDelimiterPresent);
	}

	@Test
	public void testContainsDelimiter_Comma() {
		String expression="1,2,3";
		boolean isDelimiterPresent = StringCalculatorUtil.containsDelimiter(expression, COMMA_DELIM);
		assertEquals(true, isDelimiterPresent);
	}

	@Test
	public void testContainsDelimiter_NoDelimiter() {
		String expression="1:2:3";
		boolean isDelimiterPresent = StringCalculatorUtil.containsDelimiter(expression, COMMA_DELIM);
		assertEquals(false, isDelimiterPresent);
	}
	
	@Test
	public void testContainsBothDelimiters() {
		String expression="1\n2,3";
		boolean isDelimiterPresent = StringCalculatorUtil.containsBothDelimiters(expression, NEWLINE_DELIM, COMMA_DELIM);
		assertEquals(true, isDelimiterPresent);		
	}

	@Test
	public void testContainsBothDelimiters_NotPresent() {
		String expression="1\n2\n3";
		boolean isDelimiterPresent = StringCalculatorUtil.containsBothDelimiters(expression, NEWLINE_DELIM, COMMA_DELIM);
		assertEquals(false, isDelimiterPresent);		
	}
	
	@Test
	public void testHasDelimitersNextToEachOther() {
		String expression="1,\n";
		boolean isDelimiterPresent = StringCalculatorUtil.hasDelimitersNextToEachOther(expression, NEWLINE_DELIM, COMMA_DELIM);
		assertEquals(true, isDelimiterPresent);		
	}

	@Test
	public void testHasDelimitersNextToEachOther_Valid() {
		String expression="1\n2,3";
		boolean isDelimiterPresent = StringCalculatorUtil.hasDelimitersNextToEachOther(expression, NEWLINE_DELIM, COMMA_DELIM);
		assertEquals(false, isDelimiterPresent);		
	}
	
	@Test
	public void testGetIndexes_NewLineDelimiter() {
		String expression="1\n2,3";
		List<Integer> expectedList = new ArrayList<Integer>();
		expectedList.add(1);
		List<Integer> resultList= StringCalculatorUtil.getIndexes(expression, NEWLINE_DELIM);
		assertEquals(expectedList.get(0), resultList.get(0));		
	}
	@Test
	public void testGetIndexes_CommaDelimiter() {
		String expression="1\n2,3";
		List<Integer> expectedList = new ArrayList<Integer>();
		expectedList.add(3);
		List<Integer> resultList= StringCalculatorUtil.getIndexes(expression, COMMA_DELIM);
		assertEquals(expectedList.get(0), resultList.get(0));		

	}
}
