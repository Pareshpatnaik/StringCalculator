package com.calculator.stringcalculatorapp.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.calculator.stringcalculatorapp.StringCalculator;
import com.calculator.stringcalculatorapp.exception.ParsingException;

import static org.junit.Assert.assertEquals;


public class StringCalculatorTest {

	StringCalculator stringCalculator = null;
	@Before
    public void runBeforeTestMethod() {
        System.out.println("@Before - runBeforeTestMethod");
        stringCalculator = new StringCalculator();
    }

	
	@Test
	public void testAdd_Expression0() {
		String expression="";
		int sum = stringCalculator.add(expression);
		assertEquals(-1, sum);
	}
	
	@Test
	public void testAdd_Expression1() {
		String expression="1";
		int sum = stringCalculator.add(expression);
		assertEquals(1, sum);
	}

	@Test
	public void testAdd_Expression2() {
		String expression="1,2,3";
		int sum = stringCalculator.add(expression);
		assertEquals(6, sum);
	}

	@Test
	public void testAdd_Expression3() {
		String expression="//;\n1;2";
		int sum = stringCalculator.add(expression);
		assertEquals(3, sum);
	}

	@Test
	public void testAdd_Expression4() {
		String expression="//***\n1***2***3";
		int sum = stringCalculator.add(expression);
		assertEquals(6, sum);
	}

	@Test
	public void testAdd_Expression5() {
		String expression="//*|%\n1*2%3";
		int sum = stringCalculator.add(expression);
		assertEquals(6, sum);
	}
	
	@Test
	public void testAdd_Expression6() {
		String expression="1,2,,3";
		int sum = stringCalculator.add(expression);
		assertEquals(-1, sum);
	}

	
	@Test
	public void testComputeSum_NumbersLessThan1000() {
		int[] numbers= {10,200};
		int sum = stringCalculator.computeSum(numbers);
		assertEquals(210, sum);
	}

	@Test
	public void testComputeSum_NumbersGreaterThan1000() {
		int[] numbers= {10,1001};
		int sum = stringCalculator.computeSum(numbers);
		assertEquals(10, sum);
	}

	
	@Test
	public void testValidateNumbers_ValidNumbers() throws ParsingException {
		String[] numbers = {"10","1001"};
		String[] result = stringCalculator.validateNumbers(numbers);
		assertEquals(numbers, result);
	}

	@Test(expected=ParsingException.class)
	public void testValidateNumbers_AlphaNumeric() throws ParsingException {
		String[] numbers = {"25","AB1","04"};
		String[] result = stringCalculator.validateNumbers(numbers);
	}

	@Test
	public void testValidateNegativeNumbers_PositiveNumbers() throws ParsingException {
		String[] numbers = {"10","100"};
		int[] expected = {10,100};
		int[] result = stringCalculator.validateNegativeNumbers(numbers);
		assertEquals(expected[0], result[0]);
		assertEquals(expected[1], result[1]);

	}

	@Test(expected=ParsingException.class)
	public void testValidateNegativeNumbers_NegativeNumbers() throws ParsingException {
		String[] numbers = {"-10","100"};
		int[] result = stringCalculator.validateNegativeNumbers(numbers);
	}

}
