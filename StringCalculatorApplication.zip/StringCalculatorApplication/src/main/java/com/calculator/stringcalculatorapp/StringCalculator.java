package com.calculator.stringcalculatorapp;

import static com.calculator.stringcalculatorapp.StringCalculatorConstants.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.calculator.stringcalculatorapp.exception.ParsingException;

public class StringCalculator {
	
	
	public static void main(String[] args) {
		
		StringCalculator calculator = new StringCalculator();

		String inputString = calculator.readInput(args);
		
		System.out.println("Sum : "+calculator.add(inputString.toString()));
	}
	
	/**
	 *  Method to read the user input & generate the input expression string
	 *  @param args		Variable number of User Inputs
	 *   
	 * **/
	public String readInput(String[] args) {
		
		StringBuffer strBuffer = new StringBuffer();
		System.out.println("String Calculator ");
		System.out.println("**************************************************************************");
		System.out.println("Enter Input : ");
		String input = null;
		Scanner scanner = new Scanner(System.in);
		input = scanner.nextLine();
		strBuffer.append(input);
		if ( strBuffer.length()>0 && strBuffer.toString().startsWith(DOUBLE_BACKSLASH) ) {
			strBuffer.append("\n");
			strBuffer.append(scanner.nextLine());
		}
		scanner.close();
		return strBuffer.toString();
	}

	/**
	 * Method to perform addition of the user provided input in the expression
	 * @param expression	User entered input in the form of a String
	 * 
	 * **/
	public int add(String expression) {
		
		try {

			StringCalculatorUtil.validateExpression(expression);
			
			String[] delimiterArr = getDelimiters(expression);
			
			int size = countOfDelimiterOccurrences( expression,delimiterArr );

			String splitPattern = getSplitPattern(delimiterArr);
			
			String[] numbers = getNumbers(expression, splitPattern ,size );
			
			String[] numberStrArr = validateNumbers(numbers);
			
			int[] numbersArr = validateNegativeNumbers(numberStrArr);
			
			return computeSum(numbersArr);
		
		}catch( ParsingException pe ) {
			System.out.println(pe.getMessage());
		}
		return -1;
	}

	/**
	 * Method to compute and return sum of the numbers
	 * @param numbers	An integer array of numbers 
	 * 
	 * **/
	public int computeSum( int[] numbers ) {
		
		int sum=0;
		int length = numbers.length;
		for(int i=0;i<length;i++) {
			int number = numbers[i];
			if( number <= 1000 )
				sum += number; 
		}
		return sum;
	}
	
	/**
	 * Method to validate if the numbers in the array are all digits
	 * @param numbers	An String array of numbers present in the user input separated by delimiters
	 * 
	 * **/
	public String[] validateNumbers ( String[] numbers ) throws ParsingException{
		
		int len = numbers.length;
		for(int i=0;i<len;i++) {
			String numberString = numbers[i];					
			if( numberString==null ||  ( !numberString.isEmpty() && !numberString.matches("[0-9]+") ) ){
				 throw new ParsingException(NOT_A_NUMBER+" "+numberString);
			}
		}
		return numbers;
	}

	/**
	 * Method to validate if the numbers in the array are all non-negative numbers.
	 * Returns an integer array of numbers.
	 * @param numbers	An String array of numbers present in the user input separated by delimiters
	 * 
	 * **/

	public int[]  validateNegativeNumbers( String[] numbers ) throws ParsingException{
		
		StringBuffer negativeErrorMessage = new StringBuffer(NEGATIVE_NUMBER_NOT_ALLOWED);
		int len = numbers.length;
		boolean containNegatives = false;
		int[] numArr = new int[len];
		for(int i=0;i<len;i++) {
			if( !numbers[i].isEmpty() ) {
				int number = Integer.parseInt(numbers[i]);
				numArr[i]=number;
				if ( number < 0 ) {
					containNegatives = true;
					negativeErrorMessage.append(" "+number+" ");
				}
			}
		}
		if(containNegatives)
			throw new ParsingException(negativeErrorMessage.toString());
		return numArr;
	}
	
	/**
	 * Method to get integer array of numbers from the string .
	 * Returns an string array of numbers.
	 * @param expression	A String representing user input 
	 * @param splitPattern	A String representing the delimiters in the userinput
	 * @param size			int value representing the number of delimiter occurrences in the expression	
	 * 	
	 * **/

	public String[] getNumbers( String expression , String splitPattern , int size ) throws ParsingException{
		
		String[] numbers = new String[size+1];

		if (splitPattern == null || size == 0 ) {
			numbers[0] = expression.trim();
			return numbers;
		}

		if(expression.startsWith(DOUBLE_BACKSLASH)) {
			expression = expression.substring(expression.indexOf(NEWLINE_DELIM)+1).trim();
		}
		
		String[] numberStrings = expression.split(splitPattern);
		
		int len = numberStrings.length;
		int l=0;
		for(int k=0;k<len;k++) {
			String numberString = numberStrings[k];
			if( !numberString.isEmpty() ) {
					numbers[l] = numberString.trim();
					l++;
			}
		}	
		return numbers;
	}
	
	/**
	 * Method to count of delimiters present in user input.
	 * @param expression 	User input present as a string expression
	 * @param delimiterArr	Delimiters in User input
	 * 
	 * **/
	
	public int countOfDelimiterOccurrences(String expression ,String[] delimiterArr) {
		
		if( delimiterArr == null || delimiterArr.length==0 )
			return 0;
		
		int length = delimiterArr.length;
		List<Integer> delimiterIndexesList = new ArrayList<Integer>();
		
		for(int i=0;i<length;i++) {
			List<Integer> delimList	= StringCalculatorUtil.getIndexes(expression, delimiterArr[i]);
			delimiterIndexesList.addAll(delimList); 
		}	
		return delimiterIndexesList.size();
		
	}

	/**
	 * Method to return a String of delimiters present in user input.
	 * @param delimiterArr	Delimiters in User input
	 * 
	 * **/

	public String getSplitPattern( String[] delimiterArr) {
		
		if( delimiterArr == null || delimiterArr.length==0 )
			return null;
		StringBuffer strBuff = new StringBuffer("[");
		int len = delimiterArr.length;
		for(int i=0;i<len;i++) {
			strBuff.append(delimiterArr[i]);
			if(i<len-1)
				strBuff.append("|");
		}
		strBuff.append("]");
		return strBuff.toString();
	}
	
	/**
	 * Method to return an array of delimiters present in user input.
	 * @param expression User input present as a string expression
	 * 
	 * **/

	public String[] getDelimiters(String expression) {
		
		String[] delimiterArr = null;
		String delimiterString = null;
		if( StringCalculatorUtil.containsDelimiter(expression,NEWLINE_DELIM))
			delimiterString = expression.substring(0, expression.indexOf(NEWLINE_DELIM));
		else {
			delimiterString=expression;
		}	
		
		if ( delimiterString != null && delimiterString.startsWith(DOUBLE_BACKSLASH) ) {
			
			if ( delimiterString.contains(PIPE) ) {
				delimiterArr =	getDelimitersUsingPipe(delimiterString);
			}else {
				String delimiter = delimiterString.substring(DOUBLE_BACKSLASH.length(), delimiterString.length());
				delimiterArr = new String[1];
				delimiterArr[0]=delimiter;
				}
		}else {
			if (StringCalculatorUtil.containsBothDelimiters(delimiterString, COMMA_DELIM, NEWLINE_DELIM)) {
				delimiterArr = new String[2];
				delimiterArr[0]=COMMA_DELIM;
				delimiterArr[1]=NEWLINE_DELIM;
			}else if (StringCalculatorUtil.containsDelimiter(delimiterString, COMMA_DELIM)){
				delimiterArr = new String[1];
				delimiterArr[0]=COMMA_DELIM;				
			}
		}
		return delimiterArr;
	}
	
	/**
	 * Method to return an array of delimiters present in user input separated by '|' delimiter
	 * @param Delimiter string present in between '//' and '\n' character in user input
	 * 
	 * **/

	public String[] getDelimitersUsingPipe(String delimiterString) {
		
		String delimS = delimiterString.substring(DOUBLE_BACKSLASH.length());
		StringTokenizer strTokens = new StringTokenizer(delimS, PIPE);
		List<String> delimiterList = new ArrayList<String>();
		
		while(strTokens.hasMoreTokens()) {
			delimiterList.add(strTokens.nextToken());
		}
		return StringCalculatorUtil.getStringArray(delimiterList);
	}

	
	
	
}
