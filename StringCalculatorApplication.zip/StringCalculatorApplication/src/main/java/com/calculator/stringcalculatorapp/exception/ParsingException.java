package com.calculator.stringcalculatorapp.exception;

public class ParsingException extends Exception {

	 public ParsingException(String message) {
	        super(message);
	    }
	
}